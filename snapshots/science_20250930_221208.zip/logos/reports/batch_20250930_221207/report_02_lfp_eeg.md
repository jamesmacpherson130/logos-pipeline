# Logos Report
Built: 2025-09-30 22:12:07

**Filters:** -Any lfp,eeg   
**Matches:** 1 (showing up to 50)

## Top Co-Tags (within result set)
- **anesthetized**: 1
- **gamma**: 1
- **eeg**: 1
- **rat**: 1
- **lfp**: 1
- **freely-moving**: 1
- **co2**: 1
- **near-death**: 1

## Items
* **Local field potential changes during euthanasia may parallel with near death experience**  
  - [PMC11968838](https://pmc.ncbi.nlm.nih.gov/articles/PMC11968838/) • Scientific Reports  
  - _tags:_ near-death, gamma, lfp, eeg, freely-moving, anesthetized, co2, rat
