# Logos Report
Built: 2025-09-30 22:12:07

**Filters:** -Any near-death,gamma   
**Matches:** 2 (showing up to 50)

## Top Co-Tags (within result set)
- **gamma**: 2
- **rat**: 2
- **anesthetized**: 1
- **eeg**: 1
- **lfp**: 1
- **freely-moving**: 1
- **co2**: 1
- **near-death**: 1

## Items
* **Identification of mitophagy-related key genes and their correlation with immune cell infiltration in acute myocardial infarction via bioinformatics analysis**  
  - [PMC11770045](https://pmc.ncbi.nlm.nih.gov/articles/PMC11770045/) • Frontiers in Cardiovascular Medicine  
  - _tags:_ gamma, rat

* **Local field potential changes during euthanasia may parallel with near death experience**  
  - [PMC11968838](https://pmc.ncbi.nlm.nih.gov/articles/PMC11968838/) • Scientific Reports  
  - _tags:_ near-death, gamma, lfp, eeg, freely-moving, anesthetized, co2, rat
